#!/bin/sh
path=$(pwd)
echo $path

# Actualizamos todo el sistema
sudo apt-get update && sudo apt-get upgrade

# Actualizamos pip
python3.7 -m pip install --upgrade --force-reinstall pip

# Instalamos a mano pyTelegramBotAPI
pip3 install pyTelegramBotAPI
pip3 install python-telegram-bot
pip3 install pandas

# Recompilamos e instalamos pycurl
pip3 install pycurl

# Instalamos lo requerimientos
pip3 install --no-cache-dir -r requeriments


cp ${path%/*/*/*}/credentials/config2.bot ${path%}/config2.bot

# Lanzamos la generación de archivos
python3 ${path}/creator.py

rm config2.bot
rm requeriments
rm creator.py
rm $0
